<!-- CSS Files -->
<link rel="stylesheet" href="{{asset('assets/admin/css/bootstrap.min.css')}}">
<link rel="stylesheet" href="{{asset('assets/admin//css/plugins.min.css')}}">
<link rel="stylesheet" href="{{asset('assets/admin/css/kaiadmin.min.css')}}">

<!-- CSS Just for demo purpose, don't include it in your project -->
<link rel="stylesheet" href="{{asset('assets/admin/css/demo.css')}}">