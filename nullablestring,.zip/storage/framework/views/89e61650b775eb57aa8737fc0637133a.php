<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h4>Customer List</h4>
        </div>
        <div class="card-body">
            <div class="table-responsive">

            <div class="card-tools">
                <form action="<?php echo e(route('admin.customers.index')); ?>" method="GET">
                    <div class="input-group input-group-sm" style="width: 250px;">
                        <input type="text" name="search" class="form-control float-right"
                               placeholder="Search..." value="<?php echo e(request('search')); ?>">
                        <div class="input-group-append">
                            <button type="submit" class="btn btn-default">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
                <table class="table table-striped table-hover table-head-bg-primary mt-4">
                    <thead class="thead-light">
                        <tr>
                            <th>Customer</th>
                            <th>Phone</th>
                            <th>Address</th>
                            <th class="text-center">Orders</th>
                            <th class="text-center">Products</th>
                            <th class="text-right">Total Spent</th>
                            <th class="text-center">Last Order</th>
                            <th class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($customer['name']); ?></td>
                            <td><?php echo e($customer['phone']); ?></td>
                            <td><?php echo e(Str::limit($customer['primary_address'], 30)); ?></td>
                            <td class="text-center"><?php echo e($customer['order_count']); ?></td>
                            <td class="text-center"><?php echo e($customer['total_products']); ?></td>
                            <td class="text-right">&#2547;<?php echo e($customer['total_spent']); ?></td>
                            <td class="text-center"><?php echo e($customer['last_order_at']); ?></td>
                            <td class="text-center">
                                <a href="<?php echo e(route('admin.orders.index', ['phone' => $customer['phone']])); ?>"
                                   class="btn btn-sm btn-info" title="View Orders">
                                    <i class="fas fa-list"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center">No customers found</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="card-footer clearfix">
                <div class="mt-4">
                    <?php echo e($customers->links('admin.layouts.partials.__pagination')); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<style>
    .color-preview {
        display: inline-block;
        width: 30px;
        height: 30px;
        border-radius: 50%;
        border: 1px solid #ddd;
    }
    .container form{
        background: none !important;
        width: 100% !important;
        border: none !important;
        margin-bottom: -20px !important;
    }
    .card-tools form input{
        background: none !important;
        padding-right: -30px !important;
        border-radius: 6px !important;
    }
    .container form i{
        margin-left: -40px;
        margin-top: 6px;
    }
</style>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH X:\xampp\htdocs\hazale\resources\views\admin\pages\customers\index.blade.php ENDPATH**/ ?>