<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <div class="card-title">All Users</div>
    </div>
    <div class="card-body table-responsive">
        <table class="table table-striped table-hover table-head-bg-primary mt-4">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Date</th>
                    <th scope="col">Name</th>
                    <th scope="col">Username</th>
                    
                    <th scope="col">Wallet Balance</th>
                    
                    <th scope="col">Referred By</th>
                    
                    
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($user->created_at->format('Y-m-d H:i')); ?></td>
                    <td><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></td>
                    <td><?php echo e($user->username); ?></td>
                    
                    <td><?php echo e($user->balance ?? 0); ?></td>
                    
                    <td><?php echo e($user->referrals ? $user->referred_by : 'N/A'); ?></td>
                    
                    
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($users->links('admin.layouts.partials.__pagination')); ?>

    </div>
</div>

<?php echo $__env->make('admin.modal.userblockmodal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH X:\xampp\htdocs\hazale\resources\views\admin\pages\users\index.blade.php ENDPATH**/ ?>