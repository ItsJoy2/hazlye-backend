<div class="variant-card card mb-3" data-variant-id="<?php echo e($variant->id ?? ''); ?>">
    <div class="card-header d-flex justify-content-between align-items-center">
        <span>Variant #<?php echo e($variantIndex + 1); ?></span>
        <button type="button" class="btn btn-sm btn-danger remove-variant">Remove</button>
    </div>

    <div class="card-body">
        <input type="hidden" name="variants[<?php echo e($variantIndex); ?>][id]" value="<?php echo e($variant->id ?? ''); ?>">

        <div class="form-group">
            <label>Color</label>
            <select name="variants[<?php echo e($variantIndex); ?>][color_id]" class="form-control select2" required>
                <option value="">Select Color</option>
                <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($color->id); ?>"
                        <?php echo e(($variant->color_id ?? old("variants.$variantIndex.color_id")) == $color->id ? 'selected' : ''); ?>>
                        <?php echo e($color->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group">
            <label>Variant Image</label>
            <input type="file" name="variants[<?php echo e($variantIndex); ?>][image]" class="form-control-file">
            <?php if(!empty($variant->image)): ?>
                <div class="mt-2">
                    <img src="<?php echo e(asset('storage/'.$variant->image)); ?>" class="img-thumbnail" style="max-height: 100px;">
                    <input type="hidden" name="variants[<?php echo e($variantIndex); ?>][existing_image]" value="<?php echo e($variant->image); ?>">
                </div>
            <?php endif; ?>
        </div>

        <div class="options-container mt-3" id="options-container-<?php echo e($variantIndex); ?>">
            <?php $__currentLoopData = $variant->options ?? [0 => []]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optionIndex => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('admin.pages.products.partials.__option', [
                    'variantIndex' => $variantIndex,
                    'optionIndex' => $optionIndex,
                    'option' => $option,
                    'sizes' => $sizes
                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <button type="button" class="btn btn-sm btn-secondary add-option mt-3" data-variant="<?php echo e($variantIndex); ?>">
            <i class="fas fa-plus"></i> Add Option
        </button>
    </div>
</div>
<?php /**PATH X:\xampp\htdocs\hazale\resources\views\admin\pages\products\partials\__variant.blade.php ENDPATH**/ ?>