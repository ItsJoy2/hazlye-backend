<!-- resources/views/admin/orders/show.blade.php -->



<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Order #<?php echo e($order->order_number); ?></h1>
        <a href="<?php echo e(route('admin.orders.index')); ?>" class="btn btn-secondary">Back to Orders</a>
    </div>

    <div class="row">
        <div class="col-md-8">
            <div class="card mb-4">
                <div class="card-header">
                    <h5>Order Items</h5>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Price</th>
                                <th>Qty</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($item->product_name); ?>

                                    <?php if($item->size_name): ?>
                                        <br><small>Size: <?php echo e($item->size_name); ?></small>
                                    <?php endif; ?>
                                    <?php if($item->color_name): ?>
                                        <br><small>Color: <?php echo e($item->color_name); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td>$<?php echo e(number_format($item->price, 2)); ?></td>
                                <td><?php echo e($item->quantity); ?></td>
                                <td>$<?php echo e(number_format($item->price * $item->quantity, 2)); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card mb-4">
                <div class="card-header">
                    <h5>Order Summary</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <strong>Subtotal:</strong> $<?php echo e(number_format($order->subtotal, 2)); ?>

                    </div>

                    <?php if($order->discount > 0): ?>
                    <div class="mb-3">
                        <strong>Discount:</strong> -$<?php echo e(number_format($order->discount, 2)); ?>

                        <?php if($order->coupon): ?>
                            <br><small>Coupon: <?php echo e($order->coupon->code); ?></small>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>

                    <div class="mb-3">
                        <strong>Delivery Charge:</strong> $<?php echo e(number_format($order->delivery_charge, 2)); ?>

                    </div>

                    <div class="mb-3">
                        <strong>Total:</strong> $<?php echo e(number_format($order->total, 2)); ?>

                    </div>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-header">
                    <h5>Customer Details</h5>
                </div>
                <div class="card-body">
                    <p><strong>Name:</strong> <?php echo e($order->name); ?></p>
                    <p><strong>Phone:</strong> <?php echo e($order->phone); ?></p>
                    <p><strong>Address:</strong> <?php echo e($order->address); ?></p>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h5>Update Order Status</h5>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.orders.update-status', $order)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="form-group">
                            <label for="status">Status</label>
                            <select name="status" id="status" class="form-control">
                                <option value="pending" <?php echo e($order->status == 'pending' ? 'selected' : ''); ?>>Pending</option>
                                <option value="processing" <?php echo e($order->status == 'processing' ? 'selected' : ''); ?>>Processing</option>
                                <option value="shipped" <?php echo e($order->status == 'shipped' ? 'selected' : ''); ?>>Shipped</option>
                                <option value="completed" <?php echo e($order->status == 'completed' ? 'selected' : ''); ?>>Completed</option>
                                <option value="cancelled" <?php echo e($order->status == 'cancelled' ? 'selected' : ''); ?>>Cancelled</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="comment">Comment (Optional)</label>
                            <textarea name="comment" id="comment" class="form-control" rows="3"><?php echo e(old('comment', $order->comment)); ?></textarea>
                        </div>

                        <button type="submit" class="btn btn-primary">Update Status</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH X:\xampp\htdocs\hazale\resources\views\admin\pages\orders\edit.blade.php ENDPATH**/ ?>