<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Sizes Management</h3>
            <div class="card-tools">
                <a href="<?php echo e(route('admin.sizes.create')); ?>" class="btn btn-primary btn-sm">
                    <i class="fas fa-plus"></i> Add New Size
                </a>
            </div>
        </div>
        <div class="card-body">
            <?php echo $__env->make('admin.layouts.partials.__alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <table class="table table-striped table-hover table-head-bg-primary mt-4">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Type</th>
                        <th>Size Code</th>
                        <th>Display Name</th>
                        
                        
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e(ucfirst($size->type)); ?></td>
                        <td><?php echo e($size->name); ?></td>
                        <td><?php echo e($size->display_name ?? '-'); ?></td>
                        
                        
                        <td>
                            <?php echo $__env->make('admin.pages.sizes.partials.__actions', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center">No sizes found</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer clearfix">
            <?php echo e($sizes->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH X:\xampp\htdocs\hazale\resources\views\admin\pages\sizes\index.blade.php ENDPATH**/ ?>