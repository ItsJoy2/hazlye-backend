<div class="form-group">
    <button type="submit" class="btn btn-primary">
        <i class="fas fa-save"></i> Update Color
    </button>
    <a href="<?php echo e(route('admin.colors.index')); ?>" class="btn btn-light">
        <i class="fas fa-arrow-left"></i> Cancel
    </a>
</div><?php /**PATH X:\xampp\htdocs\hazale\resources\views\admin\pages\colors\partials\__form.blade.php ENDPATH**/ ?>