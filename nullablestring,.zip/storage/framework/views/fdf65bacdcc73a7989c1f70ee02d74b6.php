<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Products Management</h3>
            <div class="card-tools">
                <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-primary btn-sm">
                    <i class="fas fa-plus"></i> Add New Product
                </a>
            </div>
        </div>
        <div class="card-body">
            <?php echo $__env->make('admin.layouts.partials.__alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <div class="table-responsive">
                <table class="table table-striped table-hover table-head-bg-primary mt-4" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Image</th>
                            <th>Buy Price</th>
                            <th>Regular sell Price</th>
                            <th>Total Stock</th>
                            <th>Category</th>
                            <th>Variants</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($product->name); ?></td>
                            <td>
                                <?php if($product->main_image): ?>
                                    <img src="<?php echo e(asset('storage/'.$product->main_image)); ?>" alt="<?php echo e($product->name); ?>" width="30" class="img-thumbnail">
                                <?php else: ?>
                                    <span class="text-muted">No main image</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e(number_format($product->buy_price, 2)); ?></td>
                            <td><?php echo e(number_format($product->regular_price, 2)); ?></td>
                            <td><?php echo e(number_format($product->total_stock)); ?> PCS</td>
                            <td><?php echo e($product->category->name ?? 'N/A'); ?></td>
                            <td>
                                <?php $__currentLoopData = $product->variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="badge bg-secondary"><?php echo e($variant->color->name); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>
                                <?php echo $__env->make('admin.pages.products.partials.__actions', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer clearfix">
            <?php echo e($products->links('admin.layouts.partials.__pagination')); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH X:\xampp\htdocs\hazale\resources\views\admin\pages\products\index.blade.php ENDPATH**/ ?>