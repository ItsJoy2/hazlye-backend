<div class="option-row row mb-2 mt-4">
    <div class="col-md-3">
        <select name="variants[<?php echo e($variantIndex); ?>][options][<?php echo e($optionIndex); ?>][size_id]" class="form-control" required>
            <option value="">Select Size</option>
            <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($size->id); ?>"
                    <?php if(isset($option['size_id']) && $option['size_id'] == $size->id): ?> selected <?php endif; ?>>
                    <?php echo e($size->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col-md-3">
        <input type="number" step="0.01" name="variants[<?php echo e($variantIndex); ?>][options][<?php echo e($optionIndex); ?>][price]"
               class="form-control" placeholder="Price" required
               value="<?php echo e($option['price'] ?? ''); ?>">
    </div>
    <div class="col-md-3">
        <input type="number" name="variants[<?php echo e($variantIndex); ?>][options][<?php echo e($optionIndex); ?>][stock]"
               class="form-control" placeholder="Stock" required
               value="<?php echo e($option['stock'] ?? ''); ?>">
    </div>
    <div class="col-md-2">
        <input type="text" name="variants[<?php echo e($variantIndex); ?>][options][<?php echo e($optionIndex); ?>][sku]"
               class="form-control" placeholder="SKU"
               value="<?php echo e($option['sku'] ?? ''); ?>" required>
    </div>
    <div class="col-md-1 d-flex align-items-center">
        <button type="button" class="btn btn-sm btn-danger remove-option">
            <i class="fas fa-trash"></i>
        </button>
    </div>

    <?php if(isset($option['id'])): ?>
        <input type="hidden" name="variants[<?php echo e($variantIndex); ?>][options][<?php echo e($optionIndex); ?>][id]" value="<?php echo e($option['id']); ?>">
    <?php endif; ?>
</div>
<?php /**PATH X:\xampp\htdocs\hazale\resources\views\admin\pages\products\partials\__option.blade.php ENDPATH**/ ?>