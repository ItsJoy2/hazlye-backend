<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Referral Settings</h2>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <form action="<?php echo e(route('admin.referral.settings.update')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label>Level 1 Bonus ($)</label>
            <input type="number" step="0.01" name="level_1_bonus" value="<?php echo e($settings->level_1_bonus); ?>" class="form-control">
        </div>

        <div class="mb-3">
            <label>Other 19 Levels Bonus ($)</label>
            <input type="number" step="0.01" name="other_levels_bonus" value="<?php echo e($settings->other_levels_bonus); ?>" class="form-control">
        </div>

        <div class="mb-3">
            <label>Reward Tokens for 20 Active Referrals</label>
            <input type="number" name="reward_tokens" value="<?php echo e($settings->reward_tokens); ?>" class="form-control">
        </div>

        <div class="mb-3">
            <label>Active Referrals Required for Reward</label>
            <input type="number" name="reward_for_users" value="<?php echo e($settings->reward_for_users); ?>" class="form-control">
        </div>

        <div class="mb-3">
            <label for="withdraw_charge">Withdrawal bonus (20 level)</label>
            <input type="number" step="0.01" name="withdraw_charge" value="<?php echo e($settings->withdraw_charge); ?>" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH X:\xampp\htdocs\hazale\resources\views\admin\pages\settings\referral_settings.blade.php ENDPATH**/ ?>