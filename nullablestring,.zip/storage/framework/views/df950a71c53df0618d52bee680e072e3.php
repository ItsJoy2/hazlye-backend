<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h3>Size Details: <?php echo e($size->name); ?></h3>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <table class="table table-bordered">
                        <tr>
                            <th>Name</th>
                            <td><?php echo e($size->name); ?></td>
                        </tr>
                        <tr>
                            <th>Products Using This Size</th>
                            <td><?php echo e($size->products->count()); ?></td>
                        </tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <?php if($size->products->count() > 0): ?>
                        <h5>Associated Products</h5>
                        <ul>
                            <?php $__currentLoopData = $size->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($product->name); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>

            <div class="mt-4">
                <a href="<?php echo e(route('admin.sizes.edit', $size->id)); ?>" class="btn btn-primary">
                    <i class="fas fa-edit"></i> Edit
                </a>
                <a href="<?php echo e(route('admin.sizes.index')); ?>" class="btn btn-light">
                    <i class="fas fa-arrow-left"></i> Back to List
                </a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH X:\xampp\htdocs\hazale\resources\views\admin\pages\delivery-options\show.blade.php ENDPATH**/ ?>