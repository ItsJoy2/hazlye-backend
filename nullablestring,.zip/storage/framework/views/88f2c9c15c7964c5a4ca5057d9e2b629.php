<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title', 'value', 'icon', 'color']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title', 'value', 'icon', 'color']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="col-md-4 col-lg-3">
    <div class="card text-white <?php echo e($color); ?> shadow-sm h-100">
        <div class="card-body d-flex align-items-center justify-content-between">
            <div>
                <h6 class="text-uppercase fw-bold"><?php echo e($title); ?></h6>
                <h4 class="fw-bold"><?php echo e($value); ?></h4>
            </div>
            <i class="<?php echo e($icon); ?> fa-2x opacity-75"></i>
        </div>
    </div>
</div>
<?php /**PATH X:\xampp\htdocs\hazale\resources\views\components\dashboard\card.blade.php ENDPATH**/ ?>