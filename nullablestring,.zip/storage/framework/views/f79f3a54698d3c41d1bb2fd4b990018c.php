<?php $__env->startSection('content'); ?>
<div class="container">

    
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <form action="<?php echo e(route('admin.general.settings.update')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>


        

        <h2>App Settings</h2>

        <div class="mb-3">
            <label for="app_name">App Name</label>
            <input type="text" id="app_name" name="app_name" value="<?php echo e(old('app_name', $generalSettings->app_name)); ?>" required class="form-control">
        </div>


        <div class="mb-3">
            <label for="favicon">Favicon(200x200px)</label>
            <input type="file" id="favicon" name="favicon" class="form-control">
            <?php if($generalSettings->favicon): ?>
                <img src="<?php echo e(asset('public/storage/' . str_replace('public/', '', $generalSettings->favicon))); ?>" alt="Current Favicon" style="max-width: 32px; max-height: 32px;">
            <?php endif; ?>
        </div>


        <div class="mb-3">
            <label for="logo">Logo(300x45px)</label>
            <input type="file" id="logo" name="logo" class="form-control">
            <?php if($generalSettings->logo): ?>
                <img src="<?php echo e(asset('public/storage/' . str_replace('public/', '', $generalSettings->logo))); ?>" alt="Current Logo" style="max-width: 300px; max-height: 45px;">
            <?php endif; ?>
        </div>


        <h2 class="mb-4">Social Links</h2>

        <div class="form-group">
            <label for="facebook_url">Facebook URL</label>
            <input type="url" class="form-control" id="facebook_url" name="facebook_url" value="<?php echo e(old('facebook_url', $generalSettings->facebook_url ?? '')); ?>" placeholder="https://www.facebook.com/">
        </div>

        <div class="form-group">
            <label for="twitter_url">Twitter URL</label>
            <input type="url" class="form-control" id="twitter_url" name="twitter_url" value="<?php echo e(old('twitter_url', $generalSettings->twitter_url ?? '')); ?>" placeholder="https://twitter.com/">
        </div>

        <div class="form-group">
            <label for="instagram_url">Instagram URL</label>
            <input type="url" class="form-control" id="instagram_url" name="instagram_url" value="<?php echo e(old('instagram_url', $generalSettings->instagram_url ?? '')); ?>" placeholder="https://www.instagram.com/">
        </div>

        <div class="form-group">
            <label for="youtube_url">YouTube URL</label>
            <input type="url" class="form-control" id="youtube_url" name="youtube_url" value="<?php echo e(old('youtube_url', $generalSettings->youtube_url ?? '')); ?>" placeholder="https://www.youtube.com/">
        </div>

        <div class="form-group">
            <label for="linkedin_url">LinkedIn URL</label>
            <input type="url" class="form-control" id="linkedin_url" name="linkedin_url" value="<?php echo e(old('linkedin_url', $generalSettings->linkedin_url ?? '')); ?>" placeholder="https://www.linkedin.com/">
        </div>

        <div class="form-group">
            <label for="tiktok_url">TikTok URL</label>
            <input type="url" class="form-control" id="tiktok_url" name="tiktok_url" value="<?php echo e(old('tiktok_url', $generalSettings->tiktok_url ?? '')); ?>" placeholder="https://www.tiktok.com/">
        </div>

        <!-- Submit Button -->
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH X:\xampp\htdocs\hazale\resources\views\admin\pages\settings\general_settings.blade.php ENDPATH**/ ?>