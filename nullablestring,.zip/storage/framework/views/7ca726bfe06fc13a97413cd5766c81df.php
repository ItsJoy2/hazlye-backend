<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header">
            <h3>Category Details: <?php echo e($category->name); ?></h3>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4">
                    <?php if($category->image): ?>
                        <img src="<?php echo e(Storage::url($category->image)); ?>" class="img-fluid" alt="Category Image">
                    <?php else: ?>
                        <div class="text-muted">No image available</div>
                    <?php endif; ?>
                </div>
                <div class="col-md-8">
                    <table class="table table-bordered">
                        <tr>
                            <th>Name</th>
                            <td><?php echo e($category->name); ?></td>
                        </tr>
                        <tr>
                            <th>Slug</th>
                            <td><?php echo e($category->slug); ?></td>
                        </tr>
                        <tr>
                            <th>Parent Category</th>
                            <td><?php echo e($category->parent->name ?? '-'); ?></td>
                        </tr>
                        <tr>
                            <th>Products Count</th>
                            <td><?php echo e($category->products->count()); ?></td>
                        </tr>
                        <tr>
                            <th>Subcategories</th>
                            <td>
                                <?php $__empty_1 = true; $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <span class="badge badge-primary"><?php echo e($child->name); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    No subcategories
                                <?php endif; ?>
                            </td>
                        </tr>
                    </table>

                    <div class="mt-4">
                        <a href="<?php echo e(route('admin.categories.edit', $category->id)); ?>" class="btn btn-primary">
                            <i class="fas fa-edit"></i> Edit
                        </a>
                        <a href="<?php echo e(route('admin.categories.index')); ?>" class="btn btn-light mx-4">
                            <i class="fas fa-arrow-left"></i> Back
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH X:\xampp\htdocs\hazale\resources\views\admin\pages\categories\show.blade.php ENDPATH**/ ?>