<footer class="footer">
    <div class="container-fluid">
        <nav class="pull-left">
            
        </nav>
        <div class="copyright text-center ms-auto">
            2024, All Rights Reserved by <a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e($generalSettings->app_name ?? 'Larabel'); ?></a>
        </div>
    </div>
</footer><?php /**PATH X:\xampp\htdocs\hazale\resources\views\admin\layouts\partials\__footer.blade.php ENDPATH**/ ?>