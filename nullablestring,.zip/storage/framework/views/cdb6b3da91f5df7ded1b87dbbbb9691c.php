<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Delivery Options</h3>
            <div class="card-tools">
                <a href="<?php echo e(route('admin.delivery-options.create')); ?>" class="btn btn-primary btn-sm">
                    <i class="fas fa-plus"></i> Add New Size
                </a>
            </div>
        </div>
        <div class="card-body">
            <?php echo $__env->make('admin.layouts.partials.__alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <table class="table table-striped table-hover table-head-bg-primary mt-4">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Charge</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $deliveryOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($option->name); ?></td>
                        <td><?php echo e(number_format($option->charge, 2)); ?></td>
                        <td>
                        <span class="badge badge-<?php echo e($option->is_active ? 'success' : 'danger'); ?>">
                            <?php echo e($option->is_active ? 'Active' : 'Inactive'); ?>

                        </span>
                    </td>
                        <td>
                            <?php echo $__env->make('admin.pages.delivery-options.partials.__actions', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center">No Delivery Options found</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer clearfix">
            <div class="mt-4">
                <?php echo e($deliveryOptions->links('admin.layouts.partials.__pagination')); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH X:\xampp\htdocs\hazale\resources\views\admin\pages\delivery-options\index.blade.php ENDPATH**/ ?>