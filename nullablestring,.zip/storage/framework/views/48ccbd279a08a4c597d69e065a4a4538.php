<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Invoice - <?php echo e($order->order_number); ?></title>
    <style>
        body {
            font-family: 'DejaVu Sans', sans-serif;
            font-size: 14px;
            line-height: 1.5;
            color: #333;
        }
        .container {
            width: 100%;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 1px solid #eee;
            padding-bottom: 20px;
        }
        .header h1 {
            margin: 0;
            color: #2d3748;
        }
        .header p {
            margin: 5px 0;
            color: #718096;
        }
        .info-section {
            display: flex;
            justify-content: space-between;
            margin-bottom: 30px;
        }
        .info-box {
            flex: 1;
            padding: 15px;
            border: 1px solid #eee;
            border-radius: 4px;
            margin: 0 10px;
        }
        .info-box h3 {
            margin-top: 0;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
            color: #2d3748;
        }
        .items-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        .items-table th {
            background-color: #f8f9fa;
            text-align: left;
            padding: 10px;
            border: 1px solid #ddd;
        }
        .items-table td {
            padding: 10px;
            border: 1px solid #ddd;
            vertical-align: top;
        }
        .items-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .variant-details {
            margin-top: 5px;
            font-size: 12px;
            color: #666;
        }
        .color-preview {
            display: inline-block;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin-right: 5px;
            border: 1px solid #ddd;
            vertical-align: middle;
        }
        .totals-section {
            float: right;
            width: 300px;
            margin-top: 20px;
        }
        .totals-table {
            width: 100%;
            border-collapse: collapse;
        }
        .totals-table td {
            padding: 8px;
            border: 1px solid #ddd;
        }
        .totals-table tr:last-child {
            font-weight: bold;
            background-color: #f8f9fa;
        }
        .footer {
            margin-top: 50px;
            text-align: center;
            font-size: 12px;
            color: #718096;
            border-top: 1px solid #eee;
            padding-top: 20px;
        }
        .status-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-weight: bold;
            text-transform: uppercase;
            font-size: 12px;
        }
        .status-pending {
            background-color: #fff3cd;
            color: #856404;
        }
        .status-processing {
            background-color: #cce5ff;
            color: #004085;
        }
        .status-completed {
            background-color: #d4edda;
            color: #155724;
        }
        .status-cancelled {
            background-color: #f8d7da;
            color: #721c24;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Order Invoice</h1>
            <p>Order #<?php echo e($order->order_number); ?></p>
            <p>Date: <?php echo e($order->created_at->format('F j, Y')); ?></p>
            <span class="status-badge status-<?php echo e($order->status); ?>">
                <?php echo e(strtoupper($order->status)); ?>

            </span>
        </div>

        <div class="info-section">
            <div class="info-box">
                <h3>Customer Information</h3>
                <p><strong>Name:</strong> <?php echo e($order->name); ?></p>
                <p><strong>Phone:</strong> <?php echo e($order->phone); ?></p>
                <p><strong>Address:</strong> <?php echo e($order->address); ?></p>
            </div>

            <div class="info-box">
                <h3>Order Details</h3>
                <p><strong>Order Number:</strong> <?php echo e($order->order_number); ?></p>
                <p><strong>Order Date:</strong> <?php echo e($order->created_at->format('F j, Y')); ?></p>
                <p><strong>Status:</strong>
                    <span class="status-badge status-<?php echo e($order->status); ?>">
                        <?php echo e(strtoupper($order->status)); ?>

                    </span>
                </p>
                <?php if($order->coupon): ?>
                    <p><strong>Coupon:</strong> <?php echo e($order->coupon_code); ?> (<?php echo e($order->coupon->discount); ?>% off)</p>
                <?php endif; ?>
            </div>
        </div>

        <h3>Order Items</h3>
        <table class="items-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Product Details</th>
                    <th>Price</th>
                    <th>Qty</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td>
                        <?php echo e($item->product_name); ?>

                        <?php if($item->size_name): ?>
                            <br><small>Size: <?php echo e($item->size_name); ?></small>
                        <?php endif; ?>
                        <?php if($item->color_name): ?>
                            <br><small>Color: <?php echo e($item->color_name); ?></small>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e(number_format($item->price, 2)); ?></td>
                    <td><?php echo e($item->quantity); ?></td>
                    <td><?php echo e(number_format($item->price * $item->quantity, 2)); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div class="totals-section">
            <table class="totals-table">
                <tr>
                    <td>Subtotal:</td>
                    <td><?php echo e(number_format($order->subtotal, 2)); ?></td>
                </tr>
                <?php if($order->discount > 0): ?>
                <tr>
                    <td>Discount:</td>
                    <td>-<?php echo e(number_format($order->discount, 2)); ?></td>
                </tr>
                <?php endif; ?>
                <tr>
                    <td>Delivery Charge:</td>
                    <td><?php echo e(number_format($order->delivery_charge, 2)); ?></td>
                </tr>
                <tr>
                    <td>Total:</td>
                    <td><?php echo e(number_format($order->total, 2)); ?></td>
                </tr>
            </table>
        </div>

        <?php if($order->comment): ?>
        <div style="margin-top: 20px; clear: both;">
            <h3>Order Notes</h3>
            <p><?php echo e($order->comment); ?></p>
        </div>
        <?php endif; ?>

        <div class="footer">
            <p>Thank you for your order!</p>
            <p><?php echo e(config('app.name')); ?> - <?php echo e(now()->format('Y')); ?></p>
        </div>
    </div>
</body>
</html><?php /**PATH X:\xampp\htdocs\hazale\resources\views\admin\layouts\invoice.blade.php ENDPATH**/ ?>