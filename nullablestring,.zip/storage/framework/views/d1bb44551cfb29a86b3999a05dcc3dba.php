<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <div class="card-title">All Users</div>
    </div>
    <div class="card-body table-responsive">
        <table class="table table-striped table-hover table-head-bg-primary mt-4">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Date</th>
                    <th scope="col">Name</th>
                    <th scope="col">Username</th>
                    <th scope="col">Email</th>
                    <th scope="col">Wallet Balance</th>
                    <th scope="col">Reward Tokens</th>
                    <th scope="col">Referred By</th>
                    <th scope="col">Status</th>
                    <th scope="col">Is Block</th>
                    <th scope="col">Wallet Status</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($user->created_at->format('Y-m-d H:i')); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->username); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td>$<?php echo e($user->wallet->wallet_balance ?? 0); ?></td>
                    <td><?php echo e($user->wallet->reward_point ?? 0); ?></td>
                    <td><?php echo e($user->referredBy ? $user->referredBy->username : 'N/A'); ?></td>
                    <td>
                        <span class="badge <?php echo e($user->is_active ? 'bg-success' : 'bg-danger'); ?>">
                            <?php echo e($user->is_active ? 'Active' : 'Inactive'); ?>

                        </span>
                    </td>
                    <td>
                        <span class="badge <?php echo e($user->is_block ? 'bg-danger' : 'bg-success'); ?>">
                            <?php echo e($user->is_block ? 'Blocked' : 'Unblock'); ?>

                        </span>
                    </td>
                    <td>
                        <span class="badge <?php echo e($user->wallet && $user->wallet->is_active ? 'bg-success' : 'bg-danger'); ?>">
                            <?php echo e($user->wallet && $user->wallet->is_active ? 'Active' : 'Freezed'); ?>

                        </span>
                    </td>
                    <td>
                        <button type="button" class="btn updateStatusBtn"
                            data-id="<?php echo e($user->id); ?>"
                            data-name="<?php echo e($user->name); ?>"
                            data-email="<?php echo e($user->email); ?>"
                            data-block="<?php echo e($user->is_block); ?>"
                            data-wallet="<?php echo e($user->wallet ? $user->wallet->is_active : 0); ?>"
                            data-toggle="modal" data-target="#actionModal">
                            <i class="fas fa-edit"></i>
                        </button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($users->links('admin.layouts.partials.__pagination')); ?>

    </div>
</div>

<?php echo $__env->make('admin.modal.userblockmodal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH X:\xampp\htdocs\hazale\resources\views\admin\pages\users\wallet_block_users.blade.php ENDPATH**/ ?>