<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h3>Edit Delivery Options: <?php echo e($size->name); ?></h3>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('admin.delivery-options.update', $deliveryOption->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <?php echo $__env->make('admin.pages.delivery-options.partials.__form', ['deliveryOption' => $deliveryOption], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <button type="submit" class="btn btn-primary">Update</button>
                <a href="<?php echo e(route('admin.delivery-options.index')); ?>" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH X:\xampp\htdocs\hazale\resources\views\admin\pages\delivery-options\edit.blade.php ENDPATH**/ ?>