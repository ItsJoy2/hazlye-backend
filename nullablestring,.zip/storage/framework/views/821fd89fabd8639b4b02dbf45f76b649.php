<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <div class="card-title">Inactive Users</div>
    </div>
    <div class="card-body table-responsive">
        <table class="table table-striped table-hover table-head-bg-primary mt-4">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Username</th>
                    <th scope="col">Email</th>
                    <th scope="col">Wallet Balance</th>
                    <th scope="col">Reward Tokens</th>
                    <th scope="col">Referred By</th>
                    <th scope="col">Status</th>
                    <th scope="col">Date</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->username); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td>$<?php echo e($user->wallet->wallet_balance ?? 0); ?></td>
                    <td><?php echo e($user->wallet->reward_point ?? 0); ?></td>
                    <td><?php echo e($user->referredBy ? $user->referredBy->username : 'N/A'); ?></td>
                    <td>
                        <span class="badge
                        <?php if($user->is_active): ?>
                            bg-success
                        <?php else: ?>
                            bg-danger
                        <?php endif; ?>
                    ">
                        <?php echo e($user->is_active ? 'Active' : 'Inactive'); ?>

                    </span>


                    </td>
                    <td><?php echo e($user->created_at->format('Y-m-d H:i')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($users->links('admin.layouts.partials.__pagination')); ?>

            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH X:\xampp\htdocs\hazale\resources\views\admin\pages\users\inactive_users.blade.php ENDPATH**/ ?>