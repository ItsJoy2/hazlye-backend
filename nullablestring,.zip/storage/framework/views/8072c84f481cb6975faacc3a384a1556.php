<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header">
            <div class="card-title">All Categories</div>
        </div>
        <div class="card-body table-responsive">
            <a href="<?php echo e(route('admin.categories.create')); ?>" class="btn btn-primary mb-4">
                <i class="fas fa-plus"></i> Create New Category
            </a>

            <div class="mt-4">
                <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            </div>

            <table class="table table-striped table-hover table-head-bg-primary mt-4">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Parent</th>
                        <th>Slug</th>
                        <th>Image</th>
                        <th>Products</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($category->name); ?></td>
                        <td><?php echo e($category->parent->name ?? '-'); ?></td>
                        <td><?php echo e($category->slug); ?></td>
                        <td>
                            <?php if($category->image): ?>
                                <img src="<?php echo e(Storage::url($category->image)); ?>" width="50" alt="Category Image">
                            <?php else: ?>
                                No image
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($category->products_count); ?></td>
                        <td>
                            <?php echo $__env->make('admin.pages.categories.partials.__actions', ['category' => $category], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center">No categories found</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <div class="mt-4">
                <?php echo e($categories->links('admin.layouts.partials.__pagination')); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH X:\xampp\htdocs\hazale\resources\views\admin\pages\categories\index.blade.php ENDPATH**/ ?>