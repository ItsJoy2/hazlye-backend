<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header">
            <h2>Edit Homepage Section <?php echo e($homepageSection->position); ?></h2>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('admin.homepage-sections.update', $homepageSection->id)); ?>" method="POST" id="sectionForm">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-3">
                    <label for="name" class="form-label">Section Name</label>
                    <input type="text" class="form-control" id="name" name="name"
                           value="<?php echo e(old('name', $homepageSection->name)); ?>" required>
                </div>

                <div class="mb-3">
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" id="is_active" name="is_active" value="1"
                               <?php echo e($homepageSection->is_active ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="is_active">Active Section</label>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Select Categories</label>
                    <select name="categories[]" id="categories" class="form-control select2" multiple="multiple" style="width: 100%;" required>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>"
                            <?php echo e(in_array($category->id, $selectedCategories) ? 'selected' : ''); ?>>
                            <?php echo e($category->name); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['categories'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <button type="submit" class="btn btn-primary">
                    Update Section
                </button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<!-- Include Select2 CSS -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

<!-- Initialize Select2 -->
<script>
    $(document).ready(function() {
        $('.select2').select2({
            placeholder: "Select categories...",
            allowClear: true,
            width: '100%'
        });

        // Form submission handling
        $('#sectionForm').on('submit', function(e) {
            // Client-side validation
            if ($('#categories').val() === null || $('#categories').val().length === 0) {
                e.preventDefault();
                alert('Please select at least one category');
                $('#categories').next('.select2-container').find('.select2-selection').focus();
                return false;
            }
            return true;
        });
    });
</script>

<!-- Include Select2 JS after initialization script -->
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH X:\xampp\htdocs\hazale\resources\views\admin\pages\homepagesection\edit.blade.php ENDPATH**/ ?>