<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title>
        <?php echo e($generalSettings->app_name ?? 'Larabel'); ?>


    </title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<link rel="icon" href="<?php echo e(Storage::url($generalSettings->favicon) ?? asset('default_favicon.ico')); ?>">
    <link rel="apple-touch-icon" href="<?php echo e(Storage::url($generalSettings->favicon) ?? asset('default_favicon.ico')); ?>">


<?php echo $__env->make('admin.layouts.partials.__style', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</head>
<body>
	<div class="wrapper">
<?php echo $__env->make('admin.layouts.partials.__sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

		<div class="main-panel">
			<div class="main-header">
				<div class="main-header-logo">
<?php echo $__env->make('admin.layouts.partials.__header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
				</div>
<?php echo $__env->make('admin.layouts.partials.__navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
			</div>

			<div class="container">
			<?php echo $__env->yieldContent('content'); ?>
			</div>

			<?php echo $__env->make('admin.layouts.partials.__footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
		</div>



	</div>
<?php echo $__env->make('admin.layouts.partials.__script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html><?php /**PATH X:\xampp\htdocs\hazale\resources\views\admin\layouts\app.blade.php ENDPATH**/ ?>