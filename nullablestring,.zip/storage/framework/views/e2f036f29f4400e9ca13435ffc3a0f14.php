<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Colors Management</h3>
            <div class="card-tools">
                <a href="<?php echo e(route('admin.colors.create')); ?>" class="btn btn-primary btn-sm">
                    <i class="fas fa-plus"></i> Add New Color
                </a>
            </div>
        </div>
        <div class="card-body">
            <?php echo $__env->make('admin.layouts.partials.__alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <table class="table table-striped table-hover table-head-bg-primary mt-4">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Color Code</th>
                        <th>Preview</th>
                        <th>Products</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=> $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($color->name); ?></td>
                        <td><?php echo e($color->code); ?></td>
                        <td>
                            <span class="color-preview" style="background-color: <?php echo e($color->code); ?>"></span>
                        </td>
                        <td><?php echo e($color->products()->count()); ?></td>
                        <td>
                           <?php echo $__env->make('admin.pages.colors.partials.__actions', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center">No colors found</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer clearfix">
            <div class="mt-4">
                <?php echo e($colors->links('admin.layouts.partials.__pagination')); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<style>
    .color-preview {
        display: inline-block;
        width: 30px;
        height: 30px;
        border-radius: 50%;
        border: 1px solid #ddd;
    }
</style>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH X:\xampp\htdocs\hazale\resources\views\admin\pages\colors\index.blade.php ENDPATH**/ ?>