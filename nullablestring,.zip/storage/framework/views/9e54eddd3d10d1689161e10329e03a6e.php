<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Coupons</h1>

    <a href="<?php echo e(route('admin.coupons.create')); ?>" class="btn btn-primary mb-3">Create New Coupon</a>
    
    <?php echo $__env->make('admin.layouts.partials.__alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="table-responsive">
        <table class="table table-striped table-hover table-head-bg-primary mt-4">
            <thead>
                <tr>
                    <th>Code</th>
                    <th>Type</th>
                    <th>Amount</th>
                    <th>Valid From</th>
                    <th>Valid To</th>
                    <th>Min Purchase</th>
                    <th>Status</th>
                    <th>Scope</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($coupon->code); ?></td>
                    <td><?php echo e(ucfirst($coupon->type)); ?></td>
                    <td><?php echo e($coupon->type === 'percentage' ? $coupon->amount.'%' : config('currency.symbol').$coupon->amount); ?></td>
                    <td><?php echo e($coupon->start_date->format('d M Y')); ?></td>
                    <td><?php echo e($coupon->end_date->format('d M Y')); ?></td>
                    <td><?php echo e(config('currency.symbol').$coupon->min_purchase); ?></td>
                    <td>
                        <span class="badge badge-<?php echo e($coupon->is_active ? 'success' : 'danger'); ?>">
                            <?php echo e($coupon->is_active ? 'Active' : 'Inactive'); ?>

                        </span>
                    </td>
                    <td><?php echo e($coupon->apply_to_all ? 'All Products' : 'Selected Products'); ?></td>
                    <td>
                        <?php echo $__env->make('admin.pages.coupons.partials.__actions', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="card-footer clearfix">
        <div class="mt-4">
            <?php echo e($coupons->links('admin.layouts.partials.__pagination')); ?>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH X:\xampp\htdocs\hazale\resources\views\admin\pages\coupons\index.blade.php ENDPATH**/ ?>