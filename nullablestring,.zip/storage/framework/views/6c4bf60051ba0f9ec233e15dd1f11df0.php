<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Homepage Sections</h1>

    <div class="card">
        <div class="card-body">
            <table class="table table-striped table-hover table-head-bg-primary mt-4">
                <thead>
                    <tr>
                        <th>Position</th>
                        <th>Name</th>
                        <th>Status</th>
                        <th>Categories</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($section->position); ?></td>
                        <td><?php echo e($section->name); ?></td>
                        <td>
                            <span class="badge bg-<?php echo e($section->is_active ? 'success' : 'danger'); ?>">
                                <?php echo e($section->is_active ? 'Active' : 'Inactive'); ?>

                            </span>
                        </td>
                        <td>
                            <?php $__currentLoopData = $section->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="badge bg-secondary"><?php echo e($category->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('admin.homepage-sections.edit', $section->id)); ?>" class="btn btn-sm btn-primary">
                                Edit
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH X:\xampp\htdocs\hazale\resources\views\admin\pages\homepagesection\index.blade.php ENDPATH**/ ?>