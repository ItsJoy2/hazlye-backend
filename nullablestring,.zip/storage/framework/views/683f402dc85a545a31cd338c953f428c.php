<div class="btn-group btn-group-sm" role="group">
    

    <a href="<?php echo e(route('admin.coupons.edit', $coupon->id)); ?>"
       class="btn btn-primary p-1 mx-1" title="Edit">
        <i class="fas fa-edit bg-none"></i>
    </a>

    <form width="0px"  action="<?php echo e(route('admin.coupons.destroy', $coupon->id)); ?>"
          method="POST" class="d-inline  m-0 p-0 border-none bg-none" style="width: 0px; height:0px;">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit" class="btn btn-danger p-0 py-1 px-2 border-none"
                title="Delete" onclick="return confirm('Are you sure?')">
            <i class="fas fa-trash"></i>
        </button>
    </form>
</div>

<?php /**PATH X:\xampp\htdocs\hazale\resources\views\admin\pages\coupons\partials\__actions.blade.php ENDPATH**/ ?>