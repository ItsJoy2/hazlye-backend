<div class="btn-group btn-group-sm" role="group">
    <a href="<?php echo e(route('admin.orders.show', $order->id)); ?>"
       class="btn btn-info p-1 mx-1" title="View">
        <i class="fas fa-eye"></i>
    </a>

    <a href="<?php echo e(route('admin.orders.edit', $order->id)); ?>"
       class="btn btn-primary p-1 mx-1" title="Edit">
        <i class="fas fa-edit bg-none"></i>
    </a>

    
</div><?php /**PATH X:\xampp\htdocs\hazale\resources\views\admin\pages\homepagesection\partials\__actions.blade.php ENDPATH**/ ?>