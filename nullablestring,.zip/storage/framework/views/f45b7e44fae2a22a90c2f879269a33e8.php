<div class="mt-4">
    <?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    
<?php endif; ?>

</div><?php /**PATH X:\xampp\htdocs\hazale\resources\views\admin\layouts\partials\__alerts.blade.php ENDPATH**/ ?>